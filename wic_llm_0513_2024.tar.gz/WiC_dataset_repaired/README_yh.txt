In this directory, you will find files named like dev_new.data.txt.
They are tokenization-adjusted data made by repair_tword_index.py.
Remind that: there are a few lines of data instances that could not be corrected/adjusted.

